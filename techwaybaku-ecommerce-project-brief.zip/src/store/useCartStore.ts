import { create } from "zustand";
import { persist } from "zustand/middleware";
import { buildWhatsAppMessage, DELIVERY_METHOD_LABELS, SHIPPING_FEE_NATIONWIDE } from "../lib/constants";
import type { CartItem, DeliveryMethod, OrderItem, Product } from "../types";

interface CartStore {
  items: CartItem[];
  deliveryMethod: DeliveryMethod;
  addItem: (product: Product) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  setDeliveryMethod: (method: DeliveryMethod) => void;
  totalItems: () => number;
  subtotal: () => number;
  discountTotal: () => number;
  shippingFee: () => number;
  finalTotal: () => number;
  toOrderItems: () => OrderItem[];
  whatsappMessage: () => string;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      deliveryMethod: "pickup",
      addItem: (product) =>
        set((state) => {
          const found = state.items.find((item) => item.productId === product.id);
          if (found) {
            return {
              items: state.items.map((item) =>
                item.productId === product.id ? { ...item, quantity: item.quantity + 1 } : item,
              ),
            };
          }

          return {
            items: [...state.items, { productId: product.id, quantity: 1, product }],
          };
        }),
      removeItem: (productId) =>
        set((state) => ({
          items: state.items.filter((item) => item.productId !== productId),
        })),
      updateQuantity: (productId, quantity) =>
        set((state) => {
          if (quantity <= 0) {
            return { items: state.items.filter((item) => item.productId !== productId) };
          }
          return {
            items: state.items.map((item) => (item.productId === productId ? { ...item, quantity } : item)),
          };
        }),
      clearCart: () => set({ items: [], deliveryMethod: "pickup" }),
      setDeliveryMethod: (method) => set({ deliveryMethod: method }),
      totalItems: () => get().items.reduce((total, item) => total + item.quantity, 0),
      subtotal: () => get().items.reduce((sum, item) => sum + item.product.price * item.quantity, 0),
      discountTotal: () =>
        get().items.reduce((sum, item) => {
          if (!item.product.oldPrice || item.product.oldPrice <= item.product.price) return sum;
          return sum + (item.product.oldPrice - item.product.price) * item.quantity;
        }, 0),
      shippingFee: () => (get().deliveryMethod === "nationwide" ? SHIPPING_FEE_NATIONWIDE : 0),
      finalTotal: () => get().subtotal() + get().shippingFee(),
      toOrderItems: () =>
        get().items.map((item) => ({
          productId: item.productId,
          title: item.product.title,
          quantity: item.quantity,
          unitPrice: item.product.price,
          oldUnitPrice: item.product.oldPrice,
          image: item.product.images[0]?.url || "",
        })),
      whatsappMessage: () =>
        buildWhatsAppMessage({
          items: get().toOrderItems(),
          deliveryMethod: get().deliveryMethod,
          finalTotal: get().finalTotal(),
        }),
    }),
    { name: "twb_cart_store" },
  ),
);

export function getDeliveryMethodText(method: DeliveryMethod) {
  return DELIVERY_METHOD_LABELS[method];
}