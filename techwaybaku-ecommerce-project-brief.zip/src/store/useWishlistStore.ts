import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { WishlistItem } from "../types";

interface WishlistStore {
  items: WishlistItem[];
  toggle: (productId: string) => void;
  isFavorite: (productId: string) => boolean;
  clear: () => void;
}

export const useWishlistStore = create<WishlistStore>()(
  persist(
    (set, get) => ({
      items: [],
      toggle: (productId) =>
        set((state) => {
          const exists = state.items.some((item) => item.productId === productId);
          if (exists) {
            return { items: state.items.filter((item) => item.productId !== productId) };
          }
          return { items: [{ productId, addedAt: new Date().toISOString() }, ...state.items] };
        }),
      isFavorite: (productId) => get().items.some((item) => item.productId === productId),
      clear: () => set({ items: [] }),
    }),
    { name: "twb_wishlist_store" },
  ),
);