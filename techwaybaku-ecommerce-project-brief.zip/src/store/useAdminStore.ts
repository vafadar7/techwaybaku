import { create } from "zustand";
import { brandRepository, categoryRepository, productRepository, promotionRepository, settingsRepository } from "../lib/repositories/productRepository";
import { orderRepository } from "../lib/repositories/orderRepository";
import type { Brand, Category, Order, Product, Promotion, Settings } from "../types";

interface AdminStore {
  products: Product[];
  categories: Category[];
  brands: Brand[];
  orders: Order[];
  promotions: Promotion[];
  settings: Settings;
  reload: () => void;
}

export const useAdminStore = create<AdminStore>((set) => ({
  products: productRepository.getAllProducts(),
  categories: categoryRepository.getAll(),
  brands: brandRepository.getAll(),
  orders: orderRepository.getAll(),
  promotions: promotionRepository.getAll(),
  settings: settingsRepository.get(),
  reload: () =>
    set({
      products: productRepository.getAllProducts(),
      categories: categoryRepository.getAll(),
      brands: brandRepository.getAll(),
      orders: orderRepository.getAll(),
      promotions: promotionRepository.getAll(),
      settings: settingsRepository.get(),
    }),
}));