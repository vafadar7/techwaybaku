import { create } from "zustand";
import type { FilterState } from "../types";

interface FilterStore {
  filters: FilterState;
  setSearch: (value: string) => void;
  toggleBrand: (id: string) => void;
  setPrice: (min?: number, max?: number) => void;
  toggleStorage: (value: string) => void;
  toggleRam: (value: string) => void;
  setPopularOnly: (value: boolean) => void;
  setCategorySlug: (slug?: string) => void;
  clearFilters: () => void;
}

const initialFilters: FilterState = {
  search: "",
  brandIds: [],
  storageOptions: [],
  ramOptions: [],
  popularOnly: false,
};

const toggleInArray = (list: string[], value: string) =>
  list.includes(value) ? list.filter((item) => item !== value) : [...list, value];

export const useFilterStore = create<FilterStore>((set) => ({
  filters: initialFilters,
  setSearch: (value) => set((state) => ({ filters: { ...state.filters, search: value } })),
  toggleBrand: (id) => set((state) => ({ filters: { ...state.filters, brandIds: toggleInArray(state.filters.brandIds, id) } })),
  setPrice: (min, max) => set((state) => ({ filters: { ...state.filters, minPrice: min, maxPrice: max } })),
  toggleStorage: (value) =>
    set((state) => ({ filters: { ...state.filters, storageOptions: toggleInArray(state.filters.storageOptions, value) } })),
  toggleRam: (value) => set((state) => ({ filters: { ...state.filters, ramOptions: toggleInArray(state.filters.ramOptions, value) } })),
  setPopularOnly: (value) => set((state) => ({ filters: { ...state.filters, popularOnly: value } })),
  setCategorySlug: (slug) => set((state) => ({ filters: { ...state.filters, categorySlug: slug } })),
  clearFilters: () => set({ filters: initialFilters }),
}));