import { initialBrands, initialCategories, initialProducts, initialPromotions, initialSettings } from "../mockData";
import { createId, slugify } from "../utils";
import type { Brand, Category, Product, Promotion, Settings } from "../../types";
import { readFromStorage, writeToStorage } from "./storage";

const KEYS = {
  products: "twb_products",
  categories: "twb_categories",
  brands: "twb_brands",
  promotions: "twb_promotions",
  settings: "twb_settings",
};

function getProducts() {
  return readFromStorage<Product[]>(KEYS.products, initialProducts);
}

function saveProducts(products: Product[]) {
  writeToStorage(KEYS.products, products);
}

export const productRepository = {
  getAllProducts: () => getProducts(),
  getPublicProducts: () => getProducts().filter((product) => product.isPublished && product.stock > 0),
  getById: (id: string) => getProducts().find((product) => product.id === id),
  getBySlug: (slug: string) => getProducts().find((product) => product.slug === slug),
  saveProduct: (payload: Omit<Product, "id" | "slug" | "createdAt"> & { id?: string }) => {
    const products = getProducts();
    if (payload.id) {
      const next = products.map((item) =>
        item.id === payload.id
          ? { ...item, ...payload, slug: slugify(payload.title), isPublished: payload.isPublished && payload.stock > 0 }
          : item,
      );
      saveProducts(next as Product[]);
      return payload.id;
    }

    const id = createId("prd");
    const nextProduct: Product = {
      ...payload,
      id,
      slug: slugify(payload.title),
      createdAt: new Date().toISOString(),
      isPublished: payload.isPublished && payload.stock > 0,
    };
    saveProducts([nextProduct, ...products]);
    return id;
  },
  deleteProduct: (id: string) => {
    const products = getProducts().filter((product) => product.id !== id);
    saveProducts(products);
  },
};

export const categoryRepository = {
  getAll: () => readFromStorage<Category[]>(KEYS.categories, initialCategories),
  saveAll: (items: Category[]) => writeToStorage(KEYS.categories, items),
  add: (name: string, icon = "Folder") => {
    const current = categoryRepository.getAll();
    const item: Category = {
      id: createId("cat"),
      name,
      slug: slugify(name),
      icon,
      order: current.length + 1,
    };
    categoryRepository.saveAll([...current, item]);
  },
  update: (id: string, name: string) => {
    const next = categoryRepository
      .getAll()
      .map((item) => (item.id === id ? { ...item, name, slug: slugify(name) } : item));
    categoryRepository.saveAll(next);
  },
  delete: (id: string) => {
    categoryRepository.saveAll(categoryRepository.getAll().filter((item) => item.id !== id));
  },
};

export const brandRepository = {
  getAll: () => readFromStorage<Brand[]>(KEYS.brands, initialBrands),
  saveAll: (items: Brand[]) => writeToStorage(KEYS.brands, items),
  add: (name: string) => {
    const current = brandRepository.getAll();
    const item: Brand = { id: createId("brand"), name, slug: slugify(name) };
    brandRepository.saveAll([...current, item]);
  },
  update: (id: string, name: string) => {
    const next = brandRepository.getAll().map((item) => (item.id === id ? { ...item, name, slug: slugify(name) } : item));
    brandRepository.saveAll(next);
  },
  delete: (id: string) => {
    brandRepository.saveAll(brandRepository.getAll().filter((item) => item.id !== id));
  },
};

export const promotionRepository = {
  getAll: () => readFromStorage<Promotion[]>(KEYS.promotions, initialPromotions),
  saveAll: (items: Promotion[]) => writeToStorage(KEYS.promotions, items),
  add: (payload: Omit<Promotion, "id">) => {
    const items = promotionRepository.getAll();
    const next: Promotion = { ...payload, id: createId("promo") };
    promotionRepository.saveAll([next, ...items]);
  },
  update: (id: string, payload: Partial<Promotion>) => {
    const next = promotionRepository.getAll().map((item) => (item.id === id ? { ...item, ...payload } : item));
    promotionRepository.saveAll(next);
  },
  delete: (id: string) => {
    promotionRepository.saveAll(promotionRepository.getAll().filter((item) => item.id !== id));
  },
};

export const settingsRepository = {
  get: () => readFromStorage<Settings>(KEYS.settings, initialSettings),
  save: (payload: Settings) => writeToStorage(KEYS.settings, payload),
};