export type DeliveryMethod = "pickup" | "nationwide";

export type OrderStatus = "new" | "contacted" | "completed" | "cancelled";

export interface ProductImage {
  id: string;
  url: string;
  alt: string;
}

export interface TechnicalSpec {
  key: string;
  value: string;
}

export interface Product {
  id: string;
  slug: string;
  title: string;
  description: string;
  price: number;
  oldPrice?: number;
  stock: number;
  categoryId: string;
  brandId: string;
  images: ProductImage[];
  specs: TechnicalSpec[];
  storage?: string;
  ram?: string;
  isPopular: boolean;
  isPublished: boolean;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  order: number;
}

export interface Brand {
  id: string;
  name: string;
  slug: string;
  logo?: string;
}

export interface OrderItem {
  productId: string;
  title: string;
  quantity: number;
  unitPrice: number;
  oldUnitPrice?: number;
  image: string;
}

export interface CartItem {
  productId: string;
  quantity: number;
  product: Product;
}

export interface WishlistItem {
  productId: string;
  addedAt: string;
}

export interface Order {
  id: string;
  createdAt: string;
  items: OrderItem[];
  deliveryMethod: DeliveryMethod;
  originalTotal: number;
  discountTotal: number;
  shippingFee: number;
  finalTotal: number;
  source: "whatsapp_checkout";
  status: OrderStatus;
}

export interface Promotion {
  id: string;
  title: string;
  content: string;
  image: string;
  date: string;
  isPublished: boolean;
}

export interface Settings {
  storeName: string;
  phone: string;
  whatsapp: string;
  address: string;
  googleMapsUrl: string;
  appleMapsUrl: string;
  aboutText: string;
}

export interface FilterState {
  search: string;
  categorySlug?: string;
  brandIds: string[];
  minPrice?: number;
  maxPrice?: number;
  storageOptions: string[];
  ramOptions: string[];
  popularOnly: boolean;
}